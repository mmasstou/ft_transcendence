

const CreatePrivateRoom = (receiver : string) => {
    
}
export default CreatePrivateRoom