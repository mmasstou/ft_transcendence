import React from 'react'
import Dashboard from '../Dashboard'

const page = () => {
  return (
    <Dashboard>
        users page
   </Dashboard>
  )
}

export default page
