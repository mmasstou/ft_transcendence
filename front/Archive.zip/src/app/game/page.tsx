import React from 'react';
import Dashboard from '../Dashboard';

const page = () => {
  return (
    <Dashboard>
      <div className='flex w-full h-full justify-center items-center bg-white'>
      game page
      </div>
   </Dashboard>
  )
}

export default page
