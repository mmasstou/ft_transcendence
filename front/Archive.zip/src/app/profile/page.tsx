import Dashboard from '../Dashboard'

const Profile = () => {
  return (
    <Dashboard>
      Main content
    </Dashboard>
  )
}

export default Profile
