

export type OLdMessages = {
    name : string,
    LastMessage:string,
    create_At: string,
    image : string
}