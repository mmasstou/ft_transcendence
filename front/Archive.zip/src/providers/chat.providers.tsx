import { createContext } from "react";

export const NotificateionChatContext = createContext([{}, () => {}]);