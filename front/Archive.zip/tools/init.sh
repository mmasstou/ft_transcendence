#!/bin/bash



exec "$@"

# tail -f

